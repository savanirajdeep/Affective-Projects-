# Pacakges

os
sys
zipfile
numpy as np
math  
sklearn  
sklearn.ensemble  
sklearn.tree  
sklearn.metrics  
sklearn.model_selection  
matplotlib.pyplot
random

# Run Project1.py file

Command line earguments format "python .\Project1.py TREE Original ./FacialLandmarks"

Command line earguments format "python .\Project1.py SVM Original ./FacialLandmarks"

Command line earguments format "python .\Project1.py RF Original ./FacialLandmarks"

# Code

The project code is in 3 files - Project1.py, data_processing.py, classification.py
